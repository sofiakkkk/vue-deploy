
$(document).ready(function(){


	/* header */
	var didScroll; // 스크롤시에 사용자가 스크롤했다는 것을 알림 
	var lastScrollTop = 0;
	var delta = 5;
	var navbarHeight = $("header").outerHeight();
	
	$(window).scroll(function(event){ 
		didScroll = true; 
	}); 
	// hasScrolled()를 실행하고 didScroll 상태를 재설정 
	setInterval(function() { 
		if (didScroll) { 
			hasScrolled(); 
			didScroll = false; 
		} 
	}, 250); 
	
	function hasScrolled() { 
		// 동작을 구현
		var st = $(this) .scrollTop();

		if(Math.abs(lastScrollTop - st) <= delta)
			return;

		if (st > lastScrollTop && st > 10){
			$("header").addClass("up");
		}else{
			if(st+$(window).height() < $(document).height()){
				$("header").removeClass("up");
			}
		}
		lastScrollTop = st;
	}

	

	/* header subMenu */
	var subMenuList = $("nav > ul > li");
	

	subMenuList.on("mouseenter focusin", function(){
		$(this).addClass("on");
		$(".searchBar").removeClass("on");
		$(".subMenu").on("mouseleave focusout", function(){
			subMenuList.removeClass("on");
		})
		
	})
	subMenuList.on("mouseleave focuout", function(){
		$(this).removeClass("on");
		
	})
	
	/* mobile hamMenu */
	var ham = $(".ham");
	$(".ham > a").on("click", function(){
		ham.addClass("on");
		$("html, body").css({
			overflow:"hidden"
		});
	})
	$(".ham .closeHam").on("click", function(){
		ham.removeClass("on");
		$("html, body").css({
			overflow:"auto"
		});
	})


	/* header language */
	$(".language > a").on("click", function(){
		$(".language").addClass("on");

		$(".language.on").on("mouseleave focusout", function(){
			$(".language").removeClass("on");
		})
	})
	
	

	/* header searchBar */
	var searchBar = $(".searchBar");
	var searchBarMob = $(".searchBar02");
	

	$(".openBtn").on("click", function(){
		searchBar.addClass("on");
		searchBarMob.addClass("on");
		
		$(".closeBtn").on("click", function(){
			searchBar.removeClass("on");
			searchBarMob.removeClass("on");
		})
		
	})
	


	/* mainText bottom bar */
	
	var bar = $(".bar");
	
	$(window).on("scroll", function(){
		if($(this).scrollTop() > 10){
			bar.css({
				width:"0",
			});
			bar.addClass("on");
		}else{
			bar.css({
				width:"100%",
				animationDelay:"0s"
			});
			bar.removeClass("on");
		}
	});

	var currentOffset = $(window).scrollTop();
		if(currentOffset != 0){
			bar.addClass("on");
		}

	/* mainText intro focusText */


	var introText = $(".intro > p");
	var introTextOffset = introText.offset();

	$(window).on("scroll", function(){
		
		var nowScroll = $(document).scrollTop();

		if(nowScroll > 500 && nowScroll <= 700){
			$(".introText01").css({
				color:"#333"
			})
		}else if(nowScroll > 750 && nowScroll <= 950){
			$(".introText01").css({
				color:"#999"
			})
			$(".introText02").css({
				color:"#333"
			})
		}else if(nowScroll > 1000){
			$(".introText02").css({
				color:"#999"
			})
			$(".introText03").css({
				color:"#333"
			})
		}else{
			$(".introText03").css({
				color:"#999"
			})
		}
	});

	/* selectbox arrow */

	var selectbox = $("#selectbox");
	selectbox.on("click", function(){
		$(this).parent("fieldset").toggleClass("on");
	})

	/* top button */

	var topBtn = $("footer > a");
	topBtn.on("click", function(){
		$("html").animate({
			scrollTop : 0
		}, 400);
		return false;
	})

	/* ham accodion */
	$(".acco-board > li > ul").hide();

	var board = $(".acco-board > li > a");
	board.parent().removeClass("on");
	
	board.click(function(){
		
		$(this).next().slideToggle();
		$(this).parent().toggleClass("on");
		board.not(this).next().slideUp().parent().removeClass("on");

	})

	$(".acco-board02 > li > ul").hide();

		var board02 = $(".acco-board02 > li > h2");
		board02.parent().removeClass("on");

		board02.click(function(){
			$(this).next().slideToggle();
			$(this).parent().toggleClass("on");
			board02.not(this).next().slideUp().parent().removeClass("on");
		})

})

